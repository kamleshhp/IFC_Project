package com.ifc.jpa;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.ifc.jpa.dao.EmployeeRepository;
import com.ifc.jpa.entities.Dependants;
import com.ifc.jpa.entities.EducationalQualification;
import com.ifc.jpa.entities.Employee;
import com.ifc.jpa.service.EmployeeService;

@RunWith(SpringRunner.class)
@SpringBootTest
class IcfProjectApplicationTests {

	
	
	@Autowired
	private EmployeeService service;
	
	@MockBean
	private EmployeeRepository repository;
	
	@Test
	public void EmployeeTest() {
		List<EducationalQualification> list1=new ArrayList<>();
		List<Dependants> list=new ArrayList<>();
		when(repository.findAll()).thenReturn(Stream.of(new Employee(100, "Kamlesh","sharma","21/02/1998","System Engineer","CSE","dd","Pre","23-02-2021","Aman","Male","A-","Hyderabad",list1,list),new Employee(100, "Kamlesh","sharma","21/02/1998","System Engineer","CSE","dd","Pre","23-02-2021","Aman","Male","A-","Hyderabad",list1,list)).collect(Collectors.toList()));
		
		assertEquals(2,service.getAll().size());
		
	}
	
	@Test
	public void saveEmployeeTest() {
		List<EducationalQualification> list1=new ArrayList<>();
		List<Dependants> list=new ArrayList<>();
		
		Employee e=new Employee(100, "Kamlesh","sharma","21/02/1998","System Engineer","CSE","dd","Pre","23-02-2021","Aman","Male","A-","Hyderabad",list1,list);
		
		when(repository.save(e)).thenReturn(e);
		
		assertEquals(e,service.saveEmployee(e));
		
		
		
		
	}
	
	@Test
	public void deleteEmployee() {
		List<EducationalQualification> list1=new ArrayList<>();
		List<Dependants> list=new ArrayList<>();
		
		Employee e=new Employee(100, "Kamlesh","sharma","21/02/1998","System Engineer","CSE","dd","Pre","23-02-2021","Aman","Male","A-","Hyderabad",list1,list);
		
		service.deleteEmployee(e.getId());
		
		((EmployeeService) verify(repository,times(1))).deleteEmployee(e.getId());
	}
	
	
}
