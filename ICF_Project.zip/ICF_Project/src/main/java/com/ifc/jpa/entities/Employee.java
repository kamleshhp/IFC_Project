package com.ifc.jpa.entities;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;



@Entity
public class Employee {
	
	@Id
	@GeneratedValue
	private int id;
	
	@NotBlank(message="User Name cannot be empty !!")
	@Size(min=3,max=12,message="User name must be between 3 - 12 characters !!")
	private String firstName;
	@NotBlank(message="User Name cannot be empty !!")
	@Size(min=1,max=10,message="User name must be between 3 - 12 characters !!")
	private String lastName;
	
	private String startDate;
	
	@NotBlank(message="Designation cannot be empty !!")
	private String designation;
	@NotBlank(message="Department cannot be empty !!")
	private String department;
	
	private String endDate;
	@AssertTrue(message="Must Agree Status !!")
	private String status;
	
	private String dob;
	
	private String reportingManager;
	@NotBlank(message="Please choose the gender")
	private String gender;
	
	private String bloodGroup;
	
	private String address;
	
	
	
	
	@OneToMany(targetEntity=EducationalQualification.class,cascade = CascadeType.ALL)
	@JoinColumn(name="cp_fk",referencedColumnName = "id")
	private List<EducationalQualification> educational;
	
	
	@OneToMany(targetEntity=Dependants.class,cascade = CascadeType.ALL)
	@JoinColumn(name="cp_fk1",referencedColumnName = "id")
	private List<Dependants> dependants;
	
	

	public Employee() {
		
	}
//	



	public Employee(int id, String firstName, String lastName, String startDate, String designation, String department,
			String endDate, String status, String dob, String reportingManager, String gender, String bloodGroup,
			String address, List<EducationalQualification> educational, List<Dependants> dependants) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.startDate = startDate;
		this.designation = designation;
		this.department = department;
		this.endDate = endDate;
		this.status = status;
		this.dob = dob;
		this.reportingManager = reportingManager;
		this.gender = gender;
		this.bloodGroup = bloodGroup;
		this.address = address;
		this.educational = educational;
		this.dependants = dependants;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getStartDate() {
		return startDate;
	}



	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}



	public String getDesignation() {
		return designation;
	}



	public void setDesignation(String designation) {
		this.designation = designation;
	}



	public String getDepartment() {
		return department;
	}



	public void setDepartment(String department) {
		this.department = department;
	}



	public String getEndDate() {
		return endDate;
	}



	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public String getDob() {
		return dob;
	}



	public void setDob(String dob) {
		this.dob = dob;
	}



	public String getReportingManager() {
		return reportingManager;
	}



	public void setReportingManager(String reportingManager) {
		this.reportingManager = reportingManager;
	}



	public String getGender() {
		return gender;
	}



	public void setGender(String gender) {
		this.gender = gender;
	}



	public String getBloodGroup() {
		return bloodGroup;
	}



	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public List<EducationalQualification> getEducational() {
		return educational;
	}



	public void setEducational(List<EducationalQualification> educational) {
		this.educational = educational;
	}



	public List<Dependants> getDependants() {
		return dependants;
	}



	public void setDependants(List<Dependants> dependants) {
		this.dependants = dependants;
	}



	@Override
	public String toString() {
		return "Employee [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", startDate=" + startDate
				+ ", designation=" + designation + ", department=" + department + ", endDate=" + endDate + ", status="
				+ status + ", dob=" + dob + ", reportingManager=" + reportingManager + ", gender=" + gender
				+ ", bloodGroup=" + bloodGroup + ", address=" + address + ", educational=" + educational
				+ ", dependants=" + dependants + "]";
	}
	
	
	
	



	
}