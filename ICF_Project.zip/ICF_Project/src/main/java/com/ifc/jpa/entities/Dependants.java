package com.ifc.jpa.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Dependants {
	
	@Id
	
	private int depentId;
	private String firstName;
	
	private String lastName;
	
private String gender;
	
	private String dob;
	
	private String relationship;
	
	
	
    
	public Dependants(int depentId, String firstName, String lastName, String gender, String dob, String relationship) {
		this.depentId = depentId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.dob = dob;
		this.relationship = relationship;
	}

	public Dependants() {
		
	}
	
	public int getDepentId() {
		return depentId;
	}

	public void setDepentId(int depentId) {
		this.depentId = depentId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	@Override
	public String toString() {
		return "Dependants [depentId=" + depentId + ", firstName=" + firstName + ", lastName=" + lastName + ", gender="
				+ gender + ", dob=" + dob + ", relationship=" + relationship + "]";
	}

	
	
	
    
}