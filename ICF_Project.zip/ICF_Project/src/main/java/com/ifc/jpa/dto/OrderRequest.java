package com.ifc.jpa.dto;

import org.springframework.beans.factory.annotation.Autowired;

import com.ifc.jpa.entities.Employee;

public class OrderRequest {
	
	@Autowired
	private Employee employee;
	
	
	
	
	

	public OrderRequest() {
		
	}
	
	

	public OrderRequest(Employee employee) {
		this.employee = employee;
	}



	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
	
	

}
