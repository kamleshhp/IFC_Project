package com.ifc.jpa.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class EducationalQualification {
	@Id
	private String type;
	private String address;
	
	private String startDate;
	
private String endDate;
	
	private String institution;
	
	
	
	private int percentage;
	
public EducationalQualification() {
		
	}



public EducationalQualification(String type, String address, String startDate, String endDate, String institution,
		int percentage) {
	this.type = type;
	this.address = address;
	this.startDate = startDate;
	this.endDate = endDate;
	this.institution = institution;
	this.percentage = percentage;
}

public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getStartDate() {
	return startDate;
}

public void setStartDate(String startDate) {
	this.startDate = startDate;
}

public String getEndDate() {
	return endDate;
}

public void setEndDate(String endDate) {
	this.endDate = endDate;
}

public String getInstitution() {
	return institution;
}

public void setInstitution(String institution) {
	this.institution = institution;
}

public int getPercentage() {
	return percentage;
}
public void setPercentage(int percentage) {
	this.percentage = percentage;
}

@Override
public String toString() {
	return "EducationalQualification [type=" + type + ", address=" + address + ", startDate=" + startDate + ", endDate="
			+ endDate + ", institution=" + institution + ", percentage=" + percentage + "]";
}


	
}