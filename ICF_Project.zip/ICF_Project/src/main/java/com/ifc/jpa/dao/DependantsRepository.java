package com.ifc.jpa.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ifc.jpa.entities.Dependants;

public interface DependantsRepository extends JpaRepository<Dependants,Integer>{
	

}
