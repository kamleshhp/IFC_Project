package com.ifc.jpa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ifc.jpa.dao.EmployeeRepository;
import com.ifc.jpa.entities.Employee;

@Service
public class EmployeeService {
	
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	
	
	public  Employee saveEmployee(Employee e) {
		
		
		return this.employeeRepository.save(e);
	}
	
	public List<Employee> getAll(){
		return this.employeeRepository.findAll();
	}
	
	public Employee getEmployeeById(int id) {
		return this.employeeRepository.findById(id).orElse(null);
	}
	
	public void deleteEmployee(int id) {
		 this.employeeRepository.deleteById(id);
	}
	
	public Employee updateEmployee(int id, Employee e) {
		
		e.setId(id);
		
		return this.employeeRepository.save(e);
	}
	
	public List<Object []> getEmployeeDependents(){
		return this.employeeRepository.getEmployeeDependent();
	}

}
