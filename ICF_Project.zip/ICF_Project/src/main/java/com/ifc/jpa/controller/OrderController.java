package com.ifc.jpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ifc.jpa.dao.EmployeeRepository;
import com.ifc.jpa.dto.OrderRequest;
import com.ifc.jpa.entities.Employee;
import com.ifc.jpa.service.EmployeeService;

@RestController
public class OrderController {
	
	@Autowired
	private EmployeeService Service;
	
	
	//private EmployeeRepository repository;
	
	
	@PostMapping("/AddEmployee")
	public Employee SaveEmployee(@RequestBody Employee e) {
		return this.Service.saveEmployee(e);
	}
	
	@GetMapping("/Employees")
	public List<Employee> getAllEmployees(){
		
		return this.Service.getAll();
	}
	
	
	
	@GetMapping("/EmployeeById/{id}")
	public Employee getEmployeeById(@PathVariable("id") int id) {
		return this.Service.getEmployeeById(id);
	}
	
	@GetMapping("/DeleteById/{id}")
	public void DeleteApi(@PathVariable("id") int id) {
		this.Service.deleteEmployee(id);
		
	}
	
	@PutMapping("/updateDetails/{id}")
	public Employee UpdateDetails(@PathVariable("id") int id ,@RequestBody Employee e) {
		return this.Service.updateEmployee(id, e);
	}
	
	@GetMapping("/dependent_details")
	public List<Object []> getEmployeewithDependent(){
		
		return this.Service.getEmployeeDependents();
		
	}
	
	
	

}
