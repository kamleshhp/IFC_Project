package com.ifc.jpa.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ifc.jpa.entities.EducationalQualification;

public interface EducationalQualificationRepository extends JpaRepository<EducationalQualification,String> {
	
	
	

}