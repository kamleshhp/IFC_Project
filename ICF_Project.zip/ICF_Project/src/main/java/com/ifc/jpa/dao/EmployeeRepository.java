package com.ifc.jpa.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ifc.jpa.entities.Employee;

public interface EmployeeRepository extends JpaRepository<Employee,Integer> {
	
	
	@Query("select e.firstName,e.department,d.firstName,d.relationship from Employee e inner join e.dependants as d")
	List<Object []> getEmployeeDependent();

}
